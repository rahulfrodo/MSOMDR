#doing 100 train test on same data###
fun<-function(it)
{
  library(mgcv)  
  #####Our method setup######################
  library(tidyverse)
  library(lubridate)
  #library(slider)
  #library(furrr)
  #library(data.table)
  ##############################################
  #load our processed data 
  load("basenewcomb_cor1final_nz_7_12_id.RData")
  ID1<-basenewcomb$ID
  basenewcomb<-basenewcomb[,-c(1302)] #dropping ID
  
  #divide into tr te#### ###fixed lambda strategy later#######
  n<-nrow(basenewcomb)
  set.seed(it)
  tridx<-sample(1:n,floor(n*.8),replace = FALSE)
  
  tr<-basenewcomb[tridx,]
  te<-basenewcomb[-tridx,]
  
  y<-basenewcomb[,c(1:3)] 
  X<- basenewcomb[,c(4,5)]
  X<-cbind(rep(1,nrow(X)),X) 
  names(X)[1]<-c("intercept")
  M<-basenewcomb[,-c(1:5)] 
  yorig<-y
  y<-as.matrix(y)
  
  ytr<-y[tridx,]
  yte<-y[-tridx,]
  
  
  K=ncol(y)#number of outcomes
  nameX<-names(X)
  nameM<-names(M)
  X<-as.matrix(X)
  M<-as.matrix(M)
  ###########################
  #n<-nrow(X)
  p1<-ncol(X)
  p2<-ncol(M)
  Yvectr<-  as.vector(t(ytr))
  Yvecte<-  as.vector(t(yte))
  constrmat<-function(colvec,rownum)
  {mat<-kronecker(diag(rownum),t(colvec))
  mat
  }
  Xmat<-list()
  for(i in 1:n)
  {Xmat[[i]]<-constrmat(X[i,],K)
  }
  
  Xmattr<-Xmat[tridx]
  Xmatte<-Xmat[-tridx]
  
  
  GrandXtr<-Reduce(rbind,Xmattr)
  GrandXte<-Reduce(rbind,Xmatte)
  
  Mmat<-list()
  for(i in 1:n)
  {Mmat[[i]]<-constrmat(M[i,],K)
  }
  
  Mmattr<-Mmat[tridx]
  Mmatte<-Mmat[-tridx]
  
  ntr<-nrow(ytr)
  nte<-nrow(yte) 
  GrandMtr<-matrix(0,nrow=length(Yvectr),ncol = p2*K)
  for(i in 1:ntr)
  {a<-(i-1)*K+1
  b<-a+K-1
  GrandMtr[a:b,]<-Mmattr[[i]]
  }
  
  GrandMte<-matrix(0,nrow=length(Yvecte),ncol = p2*K)
  for(i in 1:nte)
  {a<-(i-1)*K+1
  b<-a+K-1
  GrandMte[a:b,]<-Mmatte[[i]]
  }
  
  library(grpreg)
  GrandZtr<-cbind(GrandXtr,GrandMtr)
  GrandZte<-cbind(GrandXte,GrandMte)
  
  col1<-ncol(GrandXtr)
  group<-c()
  for (r in 1:(p2))
  {group[(0:(K-1))*p2+r+col1]<-r
  }  
  group[1:col1]<-0  
  Groupvar<-as.factor(group)
  
  library(caret)
  find1<-createFolds(y=1:ntr, k = 5, list = FALSE, returnTrain = FALSE) #may fix lambda and not do CV later###
  foldcustom<-as.vector(t(replicate(3,find1)))
  fit31 <- cv.grpreg(GrandZtr,Yvectr,Groupvar,penalty="grMCP",nfolds=5,fold = foldcustom)
  lambda<-fit31$lambda.min
  YhatpredMCP<-predict(fit31,GrandZte,type="response",lambda=lambda)
  YpredMCP<-matrix(YhatpredMCP,nrow = nte,ncol=K,byrow = TRUE)
  ###test rsq our method##
  r1sq<-1-(sum((yte[,1]-YpredMCP[,1])^2)/sum((yte[,1]-mean(yte[,1]))^2))
  r2sq<-1-sum((yte[,2]-YpredMCP[,2])^2)/sum((yte[,2]-mean(yte[,2]))^2) 
  r3sq<-1-sum((yte[,3]-YpredMCP[,3])^2)/sum((yte[,3]-mean(yte[,3]))^2)
  
  ##same tr test, tridx see competetor###
  #load basel1, basel2,basel3 from competeting methods###
  load("basel1new.RData")
  load("basel2new.RData")
  load("basel3new.RData")
  
  ##all true
  all.equal(basel1new$SEQN,ID1)
  all.equal(basel2new$SEQN,ID1)
  all.equal(basel3new$SEQN,ID1)
  
  ####TAC#######
  tr1<-basel1new[tridx,-1]
  te1<-basel1new[-tridx,-1]
  
  out2ctemp<-gam(list(CFDCSR~RIDAGEYR+sex+TAC,CFDAST~RIDAGEYR+sex+TAC,CFDDS~RIDAGEYR+sex+TAC),family=mvn(d=3),data=tr1) #delayed recall
  predmatvec<-as.numeric(predict(out2ctemp,newdata=te1,type="response"))
  predmat<-matrix(predmatvec,ncol=3,byrow =FALSE)
  
  r1sq_sum<-1-sum((te1$CFDCSR-predmat[,1])^2)/sum((te1$CFDCSR-mean(te1$CFDCSR))^2)
  r2sq_sum<-1-sum((te1$CFDAST-predmat[,2])^2)/sum((te1$CFDAST-mean(te1$CFDAST))^2)
  r3sq_sum<-1-sum((te1$CFDDS-predmat[,3])^2)/sum((te1$CFDDS-mean(te1$CFDDS))^2) 
  ###additive soqfr####
  p<-seq(0,1,l=101)
  m<-length(p)
  Pmat<-matrix(p,n,m,byrow=TRUE)
  basel2new$Pmat<-Pmat
  tr2<-basel2new[tridx,-1]
  te2<-basel2new[-tridx,-1]
  library(mgcv)
  out2ctemp<-gam(list(CFDCSR~RIDAGEYR+sex+s(Pmat,k=20,by=actqfx,bs="ps",m=2)+s(Pmat,k=20,by=actqfy,bs="ps",m=2)+s(Pmat,k=20,by=actqfz,bs="ps",m=2),CFDAST~RIDAGEYR+sex+s(Pmat,k=20,by=actqfx,bs="ps",m=2)+s(Pmat,k=20,by=actqfy,bs="ps",m=2)+s(Pmat,k=20,by=actqfz,bs="ps",m=2),CFDDS~RIDAGEYR+sex+s(Pmat,k=20,by=actqfx,bs="ps",m=2)+s(Pmat,k=20,by=actqfy,bs="ps",m=2)+s(Pmat,k=20,by=actqfz,bs="ps",m=2)),family=mvn(d=3),data=tr2) #delayed recall
  predmatvec<-as.numeric(predict(out2ctemp,newdata=te2,type="response"))
  predmat<-matrix(predmatvec,ncol=3,byrow =FALSE)
  #yte<-as.numeric(te$CFDCSR)
  r1sq_qfa<-1-sum((te2$CFDCSR-predmat[,1])^2)/sum((te2$CFDCSR-mean(te2$CFDCSR))^2)
  r2sq_qfa<-1-sum((te2$CFDAST-predmat[,2])^2)/sum((te2$CFDAST-mean(te2$CFDAST))^2)
  r3sq_qfa<-1-sum((te2$CFDDS-predmat[,3])^2)/sum((te2$CFDDS-mean(te2$CFDDS))^2) 
  ###tri MIMS soqfr####
  p<-seq(0,1,l=101)
  m<-length(p)
  Pmat<-matrix(p,n,m,byrow=TRUE)
  basel3new$Pmat<-Pmat
  tr3<-basel3new[tridx,-1]
  te3<-basel3new[-tridx,-1]
  library(mgcv)
  out2ctemp<-gam(list(CFDCSR~RIDAGEYR+sex+s(Pmat,k=20,by=actqfVM,bs="ps",m=2),CFDAST~RIDAGEYR+sex+s(Pmat,k=20,by=actqfVM,bs="ps",m=2),CFDDS~RIDAGEYR+sex+s(Pmat,k=20,by=actqfVM,bs="ps",m=2)),family=mvn(d=3),data=tr3) 
  predmatvec<-as.numeric(predict(out2ctemp,newdata=te3,type="response"))
  predmat<-matrix(predmatvec,ncol=3,byrow =FALSE)
  r1sqVM<-1-sum((te3$CFDCSR-predmat[,1])^2)/sum((te3$CFDCSR-mean(te3$CFDCSR))^2)
  r2sqVM<-1-sum((te3$CFDAST-predmat[,2])^2)/sum((te3$CFDAST-mean(te3$CFDAST))^2)
  r3sqVM<-1-sum((te3$CFDDS-predmat[,3])^2)/sum((te3$CFDDS-mean(te3$CFDDS))^2) 
  ###
  print(it)
  result<-list(r1sq=r1sq,r1sq_sum=r1sq_sum,r1sq_qfa=r1sq_qfa,r1sqVM=r1sqVM,
               r2sq=r2sq,r2sq_sum=r2sq_sum,r2sq_qfa=r2sq_qfa,r2sqVM=r2sqVM,
               r3sq=r3sq,r3sq_sum=r3sq_sum,r3sq_qfa=r3sq_qfa,r3sqVM=r3sqVM)
  return(result)
}
library(parallel)
ncores <- 10   
cl <- makeCluster(ncores)
clusterEvalQ(cl, library("mgcv"))
finalres <- parLapply(cl,c(1:100), fun) #takes long time
stopCluster(cl)
##########################################################

