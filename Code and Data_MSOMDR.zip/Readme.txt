==============================
Supplementary information used to produce the results contained within the manuscript:
TITLE: Multivariate scalar on multidimensional distribution regression with application to modelling the association between physical activity and cognitive functions
JOURNAL: Biometrical Journal
AUTHORS: Rahul Ghosal and Marcos Matabuena  
EMAIL: rghosal@mailbox.sc.edu
==============================

1. Reprouduce_MSOMDR.pdf and Reprouduce_MSOMDR.html show R Markdown illustration of the MSOMDR method in the paper and reproduces the Figures and Tables of the article. 

2. Run the Reprouduce_MSOMDR_pdf.Rmd and Reprouduce_MSOMDR.Rmd file to generate the pdf and html results. These contain the R Markdown code. (Runtime: Approx 30 minutes)


3. The code was produced with the following versions of R and packages:

 R version 4.0.4 (2021-02-15)
 Platform: x86_64-w64-mingw32/x64 (64-bit)
 Running under: Windows 10 x64 
 Matrix products: default

locale:

[1] LC_COLLATE=English_United States.1252 LC_CTYPE=English_United States.1252
[3] LC_MONETARY=English_United States.1252 LC_NUMERIC=C
[5] LC_TIME=English_United States.1252"

attached base packages:
[1] parallel  splines   stats     graphics  grDevices utils     datasets  methods   base     

other attached packages:
 [1] lubridate_1.7.10 plot3D_1.4       mgcv_1.8-33      nlme_3.1-152     caret_6.0-86     lattice_0.20-41  grpreg_3.3.0    
 [8] forcats_1.0.0    stringr_1.5.1    dplyr_1.1.4      purrr_1.0.2      readr_2.1.2      tidyr_1.2.0      tibble_3.2.1    
[15] ggplot2_3.4.4    tidyverse_1.3.1  refund_0.1-23    fda_5.1.9        fds_1.8          RCurl_1.98-1.3   rainbow_3.6     
[22] pcaPP_1.9-73     MASS_7.3-53      Matrix_1.6-5     mvnfast_0.2.7    mvtnorm_1.1-1   

loaded via a namespace (and not attached):
 [1] minqa_1.2.4          colorspace_2.0-0     class_7.3-18         mclust_5.4.7         fs_1.5.2            
 [6] rstudioapi_0.15.0    listenv_0.9.0        prodlim_2019.11.13   fansi_0.4.2          xml2_1.3.3          
[11] codetools_0.2-18     knitr_1.45           jsonlite_1.8.8       nloptr_1.2.2.2       pROC_1.17.0.1       
[16] broom_1.0.5          cluster_2.1.0        dbplyr_2.1.1         compiler_4.0.4       httr_1.4.7          
[21] backports_1.2.1      assertthat_0.2.1     fastmap_1.1.0        cli_3.6.2            htmltools_0.5.4     
[26] tools_4.0.4          misc3d_0.9-1         gtable_0.3.0         glue_1.6.2           reshape2_1.4.4      
[31] Rcpp_1.0.7           cellranger_1.1.0     vctrs_0.6.5          iterators_1.0.14     timeDate_3043.102   
[36] xfun_0.40            gower_0.2.2          globals_0.16.2       lme4_1.1-27.1        rvest_1.0.3         
[41] lifecycle_1.0.4      future_1.33.0        scales_1.2.1         ipred_0.9-11         hms_1.1.3           
[46] gamm4_0.2-6          yaml_2.3.5           rpart_4.1-15         stringi_1.5.3        foreach_1.5.2       
[51] pbs_1.1              boot_1.3-26          hdrcde_3.4           lava_1.7.2.1         rlang_1.1.3         
[56] pkgconfig_2.0.3      bitops_1.0-7         evaluate_0.23        ks_1.12.0            recipes_0.1.16      
[61] tidyselect_1.2.0     parallelly_1.36.0    plyr_1.8.6           magrittr_2.0.3       R6_2.5.1            
[66] generics_0.1.3       RLRsim_3.1-6         DBI_1.1.3            pillar_1.9.0         haven_2.4.0         
[71] withr_2.5.2          survival_3.4-0       abind_1.4-5          nnet_7.3-17          future.apply_1.11.0 
[76] modelr_0.1.8         crayon_1.5.2         KernSmooth_2.23-18   utf8_1.2.1           tzdb_0.3.0          
[81] rmarkdown_2.25       grid_4.0.4           readxl_1.3.1         data.table_1.14.2    ModelMetrics_1.2.2.2
[86] reprex_2.0.2         digest_0.6.34        stats4_4.0.4         munsell_0.5.0        tcltk_4.0.4         
[91] magic_1.6-1         


4. Other Source codes: 
i) source_MSOMDR.R file for loading the following functions for simulation illustrations.
(This supports 2 dimensional outcomes and 2-dimensional distributional predictor
as considered in simulation scenarios of the paper.)

A) Function for obtaining cross-validation error for a fixed number of basis
#@nbasisx= number of basis functions for dimension 1 (x)
#@nbasisy= number of basis functions for dimension  2 (y)
#@Ytr=   Multivariate outcome ntr*K matrix (K=2 in this implementation)
#@Ztr= scalar covariates ntr*q matrix
#@dobsMattr= an ntr*L*d array containing L observations for each distributional predictor for each training subject (ntr many), d=2 here.
Use: cvfunc(nbasisx,nbasisy,Ytr,Ztr,dobsMattr)
Value: 
#cross-validation error


B) ########Function for selecting number of basis based on cross-validation error########
#@bas1= choices for number of basis functions for dimension 1 (nbasisx)
#@bas2= choices for number of basis functions for dimension 2 (nbasisy)
#@Ytr=   Multivariate outcome ntr*K matrix (K=2 in this implementation)
#@Ztr= scalar covariates ntr*q matrix
#@dobsMattr= an ntr*L*d array containing L observations for each distributional predictor for ache subject, d=2 here.

Use: cv.select(bas1,bas2,Ytr,Ztr,dobsMattr)
Value: 
#$nbasisx
#$nbasisy

C) ########## Estimation and prediction code for MSOMDR ##############
#@nbasisx= selected number of basis functions for dimension 1 (x)
#@nbasisy= number of basis functions for dimension  2 (y)
#@Y=   Multivariate outcome n*K matrix (K=2 in this implementation)
#@Z= scalar covariates n*q matrix
#@dobsMat= an n*L*d array containing L observations for each distributional predictor for each subject (n many), d=2 here.
#@trainind= indices of training subjects
#@mm1= number of gridpoints in x direction for plotting distributional effects.
#@mm2= number of gridpoints in y direction for plotting distributional effects.
Use: MSOMDR.est(nbasisx,nbasisy,Y,Z,dobsMat,trainind,mm1=50,mm2=50)
Value: 
#$r1sqte (R-squared for the first outcome in test data)
#$r2sqte (R-squared for the second outcome in test data)
#$Ypredte (predicted multivariate outcome in test data)
#$res1est (estimated distributional effect on the first outcome,vectorized)
#$res2est (estimated distributional effect on the second outcome,vectorized)


5.
a)Reprouduce_MSOMDR.pdf and Reprouduce_MSOMDR.html show Rmarkdown illustration of the MSOMDR method 
in the paper and reproduces the Figures 1-6 in the paper and Supplemnetary Tables S1-S3 and Supplementary Figures S1-S9. 
b) The Results folder contain processed and saved data for reproducing the results.
c) Scripts folder contain additional scripts required within the RMD file. 

==============================
END
==============================

