#currently illustrated for 2 dimensional outcomes and 2-dimensional distributional predictor#
#Can be generalized to other cases#
#Function for obtaining cross-validation error for a fixed number of basis###
#@nbasisx= number of basis functions for dimension 1 (x)
#@nbasisy= number of basis functions for dimension  2 (y)
#@Ytr=   Multivariate outcome ntr*K matrix (K=2 in this implementation)
#@Ztr= scalar covariates ntr*q matrix
#@dobsMattr= an ntr*L*d array containing L observations for each distributional predictor for each training subject (ntr many), d=2 here.

cvfunc<-function(nbasisx,nbasisy,Ytr,Ztr,dobsMattr){
  library(fda)
  ntr<-nrow(Ytr)
  knotsx =seq(a1,a2,l=(nbasisx-2)) 
  knotsy =seq(b1,b2,l=(nbasisy-2)) 
  norder = 4
  # this implies the number of basis functions
  nbasisx = length(knotsx) + norder - 2
  nbasisy = length(knotsy) + norder - 2
  dayrngx = c(a1,a2)
  dayrngy = c(b1,b2) 
  bbasisx = create.bspline.basis(dayrngx,nbasisx,norder,knotsx)
  bbasisy = create.bspline.basis(dayrngy,nbasisy,norder,knotsy)
  
  
  create.wlist<-function(i)
  {
    library(fda)  
    xm<-eval.basis(dobsMattr[i,,1],bbasisx)
    ym<-eval.basis(dobsMattr[i,,2],bbasisy)
    library(mgcv)
    matlist<-list(xm,ym)
    W2mat<-tensor.prod.model.matrix(matlist)
    print(i)
    obj<-colMeans(W2mat)
    rm(W2mat)
    return(obj)
   }
  library(parallel)
  ncores <- detectCores()-1    
  cl <- makeCluster(ncores)
  clusterExport(cl, list("dobsMattr", "bbasisx","bbasisy","mouter"),envir = environment()) 
  res <- parLapply(cl,1:ntr, create.wlist)
  stopCluster(cl)
  library(tidyverse)
  Wimat<-reduce(res,rbind)
  rm(res)
  
  
  basenewcomb<-cbind(Ytr,Ztr,Wimat)
  basenewcomb<-as.data.frame(basenewcomb)
  
  names(basenewcomb)[1:2]<-paste("Y",1:2,sep="")
  names(basenewcomb)[3:4]<-paste("X",1:2,sep="")
  totbas<-nbasisx*nbasisy
  names(basenewcomb)[5:(5+totbas-1)]<-paste("comp",1:(totbas),sep="")
  names(basenewcomb)
  ###the format we want data in#############
  y<-basenewcomb[,c(1:2)] #multivar response matrix
  X<- basenewcomb[,c(3:4)]#confounding covariate matrix/ no penalty on this
  X<-cbind(rep(1,nrow(X)),X)
  names(X)[1]<-c("intercept")
  M<-basenewcomb[,-c(1:4)] #covariates for selection
  yorig<-y
  y<-as.matrix(y)
  K=ncol(y)#number of outcomes
  nameX<-names(X)
  nameM<-names(M)
  X<-as.matrix(X)
  M<-as.matrix(M)
  p1<-ncol(X)
  p2<-ncol(M)
  Yvec<-  as.vector(t(y))
  constrmat<-function(colvec,rownum)
  {mat<-kronecker(diag(rownum),t(colvec))
  mat
  }
  Xmat<-list()
  for(i in 1:ntr)
  {Xmat[[i]]<-constrmat(X[i,],K)
  }
  
  GrandX<-Reduce(rbind,Xmat)
  ####M the variable of interest############
  Mmat<-list()
  for(i in 1:ntr)
  {Mmat[[i]]<-constrmat(M[i,],K)
  }
  GrandM<-matrix(0,nrow=length(Yvec),ncol = p2*K)
  for(i in 1:ntr)
  {a<-(i-1)*K+1
  b<-a+K-1
  GrandM[a:b,]<-Mmat[[i]]
  }
  ##########
  library(grpreg)
  GrandZ<-cbind(GrandX,GrandM)
  col1<-ncol(GrandX)
  group<-c()
  for (r in 1:(p2))
  {group[(0:(K-1))*p2+r+col1]<-r
  }  
  group[1:col1]<-0  
  Groupvar<-as.factor(group)
  set.seed(123) #this varies based on seed thats why we need CV#######
  library(caret)
  find1<-createFolds(y=1:ntr, k = 5, list = FALSE, returnTrain = FALSE)
  foldcustom<-as.vector(t(replicate(K,find1)))
  fit31 <- cv.grpreg(GrandZ,Yvec,Groupvar,penalty="grMCP",nfolds=5,fold = foldcustom) #takes time
  cverror<-min(fit31$cve)
  cverror 
}


#Function for selecting number of basis based on Cross-validation error#
#@bas1= choices for number of basis functions for dimension 1 (nbasisx)
#@bas2= choices for number of basis functions for dimension 2 (nbasisy)
#@Ytr=   Multivariate outcome ntr*K matrix (K=2 in this implementation)
#@Ztr= scalar covariates ntr*q matrix
#@dobsMattr= an ntr*L*d array containing L observations for each distributional predictor for ache subject, d=2 here.

cv.select<-function(bas1=c(4:6),bas2=c(4:6),Ytr,Ztr,dobsMattr)
{gridbas<-expand.grid(nbasisx=bas1,nbasisy=bas2)
rescv<-apply(gridbas, 1, function(w){cvfunc(w["nbasisx"],w["nbasisy"],Ytr,Ztr,dobsMattr)})
minind<-which.min(rescv)
nbasisx<-gridbas[minind,1]
nbasisy<-gridbas[minind,2]  
result<-list(nbasisx=nbasisx,nbasisy=nbasisy)
return(result)
}


##Estimation and prediction code##
#@nbasisx= selected number of basis functions for dimension 1 (x)
#@nbasisy= number of basis functions for dimension  2 (y)
#@Y=   Multivariate outcome n*K matrix (K=2 in this implementation)
#@Z= scalar covariates n*q matrix
#@dobsMat= an n*L*d array containing L observations for each distributional predictor for each subject (n many), d=2 here.
#@trainind= indices of training subjects
#@mm1= number of gridpoints in x direction for plotting distributional effects.
#@mm2= number of gridpoints in y direction for plotting distributional effects.

MSOMDR.est<-function(nbasisx,nbasisy,Y,Z,dobsMat,trainind,mm1=50,mm2=50){
  knotsx =seq(a1,a2,l=(nbasisx-2)) 
  knotsy =seq(b1,b2,l=(nbasisy-2)) 
  norder = 4
  # this implies the number of basis functions
  nbasisx = length(knotsx) + norder - 2
  nbasisy = length(knotsy) + norder - 2
  dayrngx = c(a1,a2)
  dayrngy = c(b1,b2) 
  bbasisx = create.bspline.basis(dayrngx,nbasisx,norder,knotsx)
  bbasisy = create.bspline.basis(dayrngy,nbasisy,norder,knotsy)
  create.wlist<-function(i)
  {
    library(fda)  
    xm<-eval.basis(dobsMat[i,,1],bbasisx)
    ym<-eval.basis(dobsMat[i,,2],bbasisy)
    library(mgcv)
    matlist<-list(xm,ym)
    W2mat<-tensor.prod.model.matrix(matlist)
    #print(i)
    obj<-colMeans(W2mat)
    rm(W2mat)
    return(obj)
  }
  library(parallel)
  ncores <- detectCores()-1    
  cl <- makeCluster(ncores)
  clusterExport(cl, list("dobsMat", "bbasisx","bbasisy","mouter"),envir = environment()) 
  res <- parLapply(cl,1:n, create.wlist)
  stopCluster(cl)
  library(tidyverse)
  Wimat<-reduce(res,rbind)
  rm(res)
  dim(Wimat)
  basenewcomb<-cbind(Y,Z,Wimat)
  basenewcomb<-as.data.frame(basenewcomb)
  
  names(basenewcomb)[1:2]<-paste("Y",1:2,sep="")
  names(basenewcomb)[3:4]<-paste("X",1:2,sep="")
  totbas<-nbasisx*nbasisy
  names(basenewcomb)[5:(5+totbas-1)]<-paste("comp",1:(totbas),sep="")
  names(basenewcomb)
  ####
  basenewcombtr<-basenewcomb[trainind,]
  basenewcombte<-basenewcomb[-trainind,]
  
  ###the format we want data in#############
  y<-basenewcomb[,c(1:2)] #multivariate response matrix
  ytr<-basenewcombtr[,c(1:2)] 
  yte<-basenewcombte[,c(1:2)] 
  X<- basenewcomb[,c(3:4)]#confounding covariate matrix
  X<-cbind(rep(1,nrow(X)),X)
  names(X)[1]<-c("intercept")
  M<-basenewcomb[,-c(1:4)] #distributional covariate components
  y<-as.matrix(y)
  ytr<-as.matrix(ytr)
  yte<-as.matrix(yte)
  ntr<-nrow(ytr)
  K=ncol(y)#number of outcomes
  nameX<-names(X)
  nameM<-names(M)
  X<-as.matrix(X)
  M<-as.matrix(M)
  p1<-ncol(X)
  p2<-ncol(M)
  Yvec<-  as.vector(t(y))
  Yvectr<-  as.vector(t(ytr))
  Yvecte<-  as.vector(t(yte))
  constrmat<-function(colvec,rownum)
  {mat<-kronecker(diag(rownum),t(colvec))
  mat
  }
  Xmat<-list()
  for(i in 1:n)
  {Xmat[[i]]<-constrmat(X[i,],K)
  }
  
  Xmattr<-Xmat[trainind]
  Xmatte<-Xmat[-trainind]
  GrandXtr<-Reduce(rbind,Xmattr)
  GrandXte<-Reduce(rbind,Xmatte)
  
  Mmat<-list()
  for(i in 1:n)
  {Mmat[[i]]<-constrmat(M[i,],K)
  }
  Mmattr<-Mmat[trainind]
  Mmatte<-Mmat[-trainind]
  
  GrandMtr<-matrix(0,nrow=length(Yvectr),ncol = p2*K)
  for(i in 1:ntr)
  {a<-(i-1)*K+1
  b<-a+K-1
  GrandMtr[a:b,]<-Mmattr[[i]]
  }
  nte<-n-ntr
  GrandMte<-matrix(0,nrow=length(Yvecte),ncol = p2*K)
  for(i in 1:nte)
  {a<-(i-1)*K+1
  b<-a+K-1
  GrandMte[a:b,]<-Mmatte[[i]]
  }
  ##########
  library(grpreg)
  GrandZtr<-cbind(GrandXtr,GrandMtr)
  GrandZte<-cbind(GrandXte,GrandMte)
  col1<-ncol(GrandXtr)
  group<-c()
  for (r in 1:(p2))
  {group[(0:(K-1))*p2+r+col1]<-r
  }  
  group[1:col1]<-0  
  Groupvar<-as.factor(group)
  set.seed(123) #######
  library(caret)
  find1<-createFolds(y=1:ntr, k = 5, list = FALSE, returnTrain = FALSE)
  foldcustom<-as.vector(t(replicate(K,find1)))
  fit31 <- cv.grpreg(GrandZtr,Yvectr,Groupvar,penalty="grMCP",nfolds=5,fold = foldcustom) 
  lambda<-fit31$lambda.min 
  gamma2<-coef(fit31)
  indsel2<-which(gamma2[-1]!=0)
  scnum<-(K*p1+1) #K outcomes
  betaest<-gamma2[-c(1:scnum)]
  #varselected1<- nameM[which(betaest[1:totbas]!=0)]#
  #varselected2<- nameM[which(betaest[(totbas+1):(2*totbas)]!=0)]#
  ###Prediction test set#######
  YhatpredMCPte<-predict(fit31,GrandZte,type="response",lambda=lambda)
  YpredMCPte<-matrix(YhatpredMCPte,nrow = nte,ncol=K,byrow = TRUE)
  r1sqte<-1-(sum((yte[,1]-YpredMCPte[,1])^2)/sum((yte[,1]-mean(yte[,1]))^2))
  r2sqte<-1-sum((yte[,2]-YpredMCPte[,2])^2)/sum((yte[,2]-mean(yte[,2]))^2) 
  cbind(r1sqte,r2sqte)
  ##effect basis coeffcient for two outcomes##
  beta1vec_grmcp<-as.numeric(betaest[1:totbas])+gamma2[1]+gamma2[(1+1)]
  beta2vec_grmcp<-as.numeric(betaest[(totbas+1):(2*totbas)])+gamma2[1]+gamma2[(1+p1+1)]
  betafun_1<-function(x,y)
  {
    library(fda)  
    xm<-eval.basis(x,bbasisx)
    ym<-eval.basis(y,bbasisy)
    #print(i)
    library(mgcv)
    matlist<-list(xm,ym)
    W2mat<-tensor.prod.model.matrix(matlist)
    objval<-as.numeric(W2mat%*%beta1vec_grmcp) #colMeans(W2mat)
    rm(W2mat)
    return(objval)
  }
  #a1r<-c()
  #a2r<-c()
  #b1r<-c()
  #b2r<-c()
  #for(i in 1:n)
  #{a1r[i]<-min(dobsMat[i,,1])
  #a2r[i]<-max(dobsMat[i,,1])
  #b1r[i]<-min(dobsMat[i,,2])
  #b2r[i]<-max(dobsMat[i,,2])
  #}
  #amin<-(max(a1r)+quantile(a1r,probs = 0.75))/2
  #amax<-(min(a2r)+quantile(a2r,probs = 0.25))/2
  #bmin<-(max(b1r)+quantile(b1r,probs = 0.75))/2
  #bmax<-(min(b2r)+quantile(b2r,probs = 0.25))/2
  
  xseq<-seq(-2,2,l=50) #grid for evalutaing functions, has to be in the union of supports## look at \approx (amin,amax)
  yseq<-seq(-2,2,l=50) #look at \approx (bmin,bmax)
  
  grid<-expand.grid(x=xseq,y=yseq)
  res1est<-apply(grid, 1, function(w){betafun_1(w["x"],w["y"])}) #estimated beta1(x,y) vectorized
  betafun_2<-function(x,y)
  {
    library(fda)  
    xm<-eval.basis(x,bbasisx)
    ym<-eval.basis(y,bbasisy)
    library(mgcv)
    matlist<-list(xm,ym)
    W2mat<-tensor.prod.model.matrix(matlist)
    objval<-as.numeric(W2mat%*%beta2vec_grmcp) #colMeans(W2mat)
    rm(W2mat)
    return(objval)
  }
  
  #V20 <- outer(xseq,yseq,cone2)
  grid<-expand.grid(x=xseq,y=yseq)
  res2est<-apply(grid, 1, function(w){betafun_2(w["x"],w["y"])}) #estimated beta2(x,y) vectorized
  #V<-matrix(res2,mm1,mm2,byrow = FALSE) #in matrix form
  #persp(xseq, yseq, V,phi = 40,theta = -50, expand = 0.5, col = "lightblue",ticktype = "detailed")
  result<-list(r1sqte=r1sqte,r2sqte=r2sqte,Ypredte=YpredMCPte,res1est=res1est,res2est=res2est)
  return(result)
}  

