1. MSOMDR.html show illustration of the MSOMDR method in the paper.  

2. MSOMDR.Rmd file contains the R markdown code for the same.

3. Source the source_MSOMDR.R file for loading the following functions.
Provided code currently supports 2 dimensional outcomes and 2-dimensional distributional predictor.
Easily extendable to implement other scenarios.

i) Function for obtaining cross-validation error for a fixed number of basis
#@nbasisx= number of basis functions for dimension 1 (x)
#@nbasisy= number of basis functions for dimension  2 (y)
#@Ytr=   Multivariate outcome ntr*K matrix (K=2 in this implementation)
#@Ztr= scalar covariates ntr*q matrix
#@dobsMattr= an ntr*L*d array containing L observations for each distributional predictor for each training subject (ntr many), d=2 here.
Use: cvfunc(nbasisx,nbasisy,Ytr,Ztr,dobsMattr)
Value: 
#cross-validation error


ii) ########Function for selecting number of basis based on cross-validation error########
#@bas1= choices for number of basis functions for dimension 1 (nbasisx)
#@bas2= choices for number of basis functions for dimension 2 (nbasisy)
#@Ytr=   Multivariate outcome ntr*K matrix (K=2 in this implementation)
#@Ztr= scalar covariates ntr*q matrix
#@dobsMattr= an ntr*L*d array containing L observations for each distributional predictor for ache subject, d=2 here.

Use: cv.select(bas1,bas2,Ytr,Ztr,dobsMattr)
Value: 
#$nbasisx
#$nbasisy

iii) ########## Estimation and prediction code for MSOMDR ##############
#@nbasisx= selected number of basis functions for dimension 1 (x)
#@nbasisy= number of basis functions for dimension  2 (y)
#@Y=   Multivariate outcome n*K matrix (K=2 in this implementation)
#@Z= scalar covariates n*q matrix
#@dobsMat= an n*L*d array containing L observations for each distributional predictor for each subject (n many), d=2 here.
#@trainind= indices of training subjects
#@mm1= number of gridpoints in x direction for plotting distributional effects.
#@mm2= number of gridpoints in y direction for plotting distributional effects.
Use: MSOMDR.est(nbasisx,nbasisy,Y,Z,dobsMat,trainind,mm1=50,mm2=50)
Value: 
#$r1sqte (R-squared for the first outcome in test data)
#$r2sqte (R-squared for the second outcome in test data)
#$Ypredte (predicted multivariate outcome in test data)
#$res1est (estimated distributional effect on the first outcome,vectorized)
#$res2est (estimated distributional effect on the second outcome,vectorized)
